import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const node = process.execPath;
const runtimeUrl = 'http://127.0.0.1:4259';
const chiefUrl = 'http://127.0.0.1:4260';

async function isOnline(url) {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(800) });
    return response.ok;
  } catch {
    return false;
  }
}

async function waitFor(url, attempts = 80) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await isOnline(url)) return true;
    await sleep(250);
  }
  return false;
}

async function startAll() {
  try {
    const response = await fetch(`${runtimeUrl}/v1/start-all`, {
      method: 'POST',
      signal: AbortSignal.timeout(10000),
    });
    return response.ok;
  } catch {
    return false;
  }
}

function startRuntime() {
  const child = spawn(node, ['scripts/start-chief-v1.mjs'], {
    cwd: repoRoot,
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
    env: process.env,
  });
  child.unref();
}

function openBrowser(url) {
  if (process.env.HERCHI26_NO_BROWSER === '1') return;

  if (process.platform === 'darwin') {
    spawn('/usr/bin/open', [url], { detached: true, stdio: 'ignore' }).unref();
    return;
  }

  if (process.platform === 'win32') {
    spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    return;
  }

  spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
}

if (!(await isOnline(`${runtimeUrl}/health`))) {
  console.log('HERCHI26 Runtime wird gestartet ...');
  startRuntime();
} else {
  console.log('HERCHI26 Runtime läuft bereits.');
}

const runtimeReady = await waitFor(`${runtimeUrl}/health`);
if (runtimeReady) await startAll();
const chiefReady = runtimeReady ? await waitFor(chiefUrl) : false;

if (!runtimeReady || !chiefReady) {
  console.error('HERCHI26 konnte nicht vollständig gestartet werden.');
  process.exit(1);
}

console.log('HERCHI26 ist bereit.');
console.log(`Chief: ${chiefUrl}`);
openBrowser(chiefUrl);
