import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const root = path.join(repoRoot, 'apps', 'chief-v1', 'dist');
const port = Number(process.env.HERCHI26_CHIEF_PORT ?? 4260);

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

async function readFileForRequest(urlPath) {
  const clean = decodeURIComponent((urlPath || '/').split('?')[0]);
  const relative = clean === '/' ? 'index.html' : clean.replace(/^\/+/, '');
  const candidate = path.resolve(root, relative);
  const rootResolved = path.resolve(root);
  if (!candidate.startsWith(`${rootResolved}${path.sep}`) && candidate !== path.join(rootResolved, 'index.html')) return null;
  try {
    const stat = await fs.stat(candidate);
    if (!stat.isFile()) return null;
    return { path: candidate, content: await fs.readFile(candidate) };
  } catch {
    return null;
  }
}

function cpuTotals() {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    idle += cpu.times.idle;
    total += cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq;
  }
  return { idle, total };
}

async function cpuPercent() {
  const before = cpuTotals();
  await sleep(140);
  const after = cpuTotals();
  const totalDelta = after.total - before.total;
  const idleDelta = after.idle - before.idle;
  if (totalDelta <= 0) return null;
  return Math.max(0, Math.min(100, Math.round((1 - idleDelta / totalDelta) * 100)));
}

async function readSystemMetrics() {
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const memoryPercent = totalMemory > 0
    ? Math.max(0, Math.min(100, Math.round(((totalMemory - freeMemory) / totalMemory) * 100)))
    : null;

  let storagePercent = null;
  try {
    const stat = await fs.statfs(repoRoot);
    const total = Number(stat.blocks) * Number(stat.bsize);
    const available = Number(stat.bavail) * Number(stat.bsize);
    if (total > 0) storagePercent = Math.max(0, Math.min(100, Math.round(((total - available) / total) * 100)));
  } catch {
    storagePercent = null;
  }

  return {
    cpuPercent: await cpuPercent(),
    memoryPercent,
    storagePercent,
    cpuCount: os.cpus().length,
    totalMemoryBytes: totalMemory,
    checkedAt: new Date().toISOString(),
    source: 'LOCAL_MAC_RUNTIME',
  };
}

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
    Pragma: 'no-cache',
    Expires: '0',
  });
  response.end(JSON.stringify(body));
}

const server = http.createServer(async (request, response) => {
  const requestUrl = new URL(request.url ?? '/', `http://127.0.0.1:${port}`);

  if (request.method === 'GET' && requestUrl.pathname === '/v1/system/metrics') {
    try {
      sendJson(response, 200, await readSystemMetrics());
    } catch (error) {
      sendJson(response, 500, {
        error: 'SYSTEM_METRICS_FAILED',
        message: error instanceof Error ? error.message : 'Systemmetriken konnten nicht gelesen werden.',
        checkedAt: new Date().toISOString(),
      });
    }
    return;
  }

  const found = await readFileForRequest(request.url ?? '/');
  if (found) {
    response.writeHead(200, {
      'Content-Type': contentTypes[path.extname(found.path)] ?? 'application/octet-stream',
      // Chief runs only locally and changes frequently during the rebuild. Never let Safari
      // reuse an older updater/version script across installs.
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      Pragma: 'no-cache',
      Expires: '0',
    });
    response.end(found.content);
    return;
  }

  // SPA fallback for Chief routes.
  try {
    const index = await fs.readFile(path.join(root, 'index.html'));
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      Pragma: 'no-cache',
      Expires: '0',
    });
    response.end(index);
  } catch {
    response.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('HERCHI26 Chief build fehlt.');
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`HERCHI26 Chief static server listening on http://127.0.0.1:${port}`);
});
