import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const root = path.join(repoRoot, 'apps', 'chief-v1', 'dist');
const port = Number(process.env.HERCHI26_CHIEF_PORT ?? 4260);

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

async function readFileForRequest(urlPath) {
  const clean = decodeURIComponent((urlPath || '/').split('?')[0]);
  const relative = clean === '/' ? 'index.html' : clean.replace(/^\/+/, '');
  const candidate = path.resolve(root, relative);
  const rootResolved = path.resolve(root);
  if (!candidate.startsWith(`${rootResolved}${path.sep}`) && candidate !== path.join(rootResolved, 'index.html')) return null;
  try {
    const stat = await fs.stat(candidate);
    if (!stat.isFile()) return null;
    return { path: candidate, content: await fs.readFile(candidate) };
  } catch {
    return null;
  }
}

const server = http.createServer(async (request, response) => {
  const found = await readFileForRequest(request.url ?? '/');
  if (found) {
    response.writeHead(200, {
      'Content-Type': contentTypes[path.extname(found.path)] ?? 'application/octet-stream',
      // Chief runs only locally and changes frequently during the rebuild. Never let Safari
      // reuse an older updater/version script across installs.
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      Pragma: 'no-cache',
      Expires: '0',
    });
    response.end(found.content);
    return;
  }

  // SPA fallback for Chief routes.
  try {
    const index = await fs.readFile(path.join(root, 'index.html'));
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      Pragma: 'no-cache',
      Expires: '0',
    });
    response.end(index);
  } catch {
    response.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('HERCHI26 Chief build fehlt.');
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`HERCHI26 Chief static server listening on http://127.0.0.1:${port}`);
});
