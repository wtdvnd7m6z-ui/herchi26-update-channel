import http from 'node:http';
import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { homedir } from 'node:os';
import { setTimeout as sleep } from 'node:timers/promises';
import {
  checkForUpdate,
  prepareUpdate,
  readCurrentVersion,
  setUpdateChannelConfig,
} from './update-core-v1.mjs';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const node = process.execPath;
const viteCli = path.join(repoRoot, 'apps', 'chief-v1', 'node_modules', 'vite', 'bin', 'vite.js');
const staticChiefScript = path.join(repoRoot, 'scripts', 'serve-chief-v1.mjs');
const staticChiefIndex = path.join(repoRoot, 'apps', 'chief-v1', 'dist', 'index.html');
const applyUpdateScript = path.join(repoRoot, 'scripts', 'apply-update-v1.mjs');
const RUNTIME_PORT = 4259;
const CHIEF_URL = 'http://127.0.0.1:4260';
const COMMS_URL = 'http://127.0.0.1:4261';
const RESOURCE_CACHE_MS = 60_000;

let chief = null;
let communication = null;
let stopping = false;
let updateApplying = false;
let resourceCache = null;
let resourceCacheAt = 0;
let resourceRefreshInFlight = null;

const corsHeaders = {
  'Access-Control-Allow-Origin': 'http://127.0.0.1:4260',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, {
    ...corsHeaders,
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(JSON.stringify(body));
}

async function readJson(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

async function exists(file) {
  try { await fs.access(file); return true; } catch { return false; }
}

async function readDirSafe(directory, options = undefined) {
  try { return await fs.readdir(directory, options); } catch { return []; }
}

async function isHttpOk(url) {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(700) });
    return response.ok;
  } catch {
    return false;
  }
}

async function waitUntilOnline(url, attempts = 30) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await isHttpOk(url)) return true;
    await sleep(150);
  }
  return false;
}

function watchChild(name, child) {
  child.on('exit', (code) => {
    if (!stopping && code && code !== 0) console.error(`${name} stopped with code ${code}`);
    if (name === 'COMMS') communication = null;
    if (name === 'CORE') chief = null;
  });
}

async function ensureComms() {
  if (await isHttpOk(`${COMMS_URL}/health`)) return;
  if (communication && communication.exitCode === null) return;

  communication = spawn(node, ['apps/communication-v1/server.mjs'], {
    cwd: repoRoot,
    stdio: 'inherit',
    env: process.env,
  });
  watchChild('COMMS', communication);
  await waitUntilOnline(`${COMMS_URL}/health`);
}

async function ensureChief() {
  if (await isHttpOk(CHIEF_URL)) return;
  if (chief && chief.exitCode === null) return;

  const productionBuildExists = await exists(staticChiefIndex);
  const args = productionBuildExists
    ? [staticChiefScript]
    : [viteCli, '--host', '127.0.0.1', '--port', '4260'];
  const cwd = productionBuildExists ? repoRoot : path.join(repoRoot, 'apps', 'chief-v1');

  chief = spawn(node, args, {
    cwd,
    stdio: 'inherit',
    env: process.env,
  });
  watchChild('CORE', chief);
  await waitUntilOnline(CHIEF_URL, 50);
}

async function getRuntimeStatus() {
  const [chiefOnline, commsOnline] = await Promise.all([
    isHttpOk(CHIEF_URL),
    isHttpOk(`${COMMS_URL}/health`),
  ]);
  let version = null;
  try { version = await readCurrentVersion(repoRoot); } catch {}

  return {
    runtime: 'ONLINE',
    checkedAt: new Date().toISOString(),
    version,
    updateApplying,
    services: [
      { id: 'CORE', name: 'Chief Platform', status: chiefOnline ? 'ONLINE' : 'OFFLINE', endpoint: CHIEF_URL },
      { id: 'COMMS', name: 'Mail & Kommunikation', status: commsOnline ? 'ONLINE' : 'OFFLINE', endpoint: COMMS_URL },
      { id: 'SEA', name: 'SEA', status: 'NOT_BUILT' },
      { id: 'FIN', name: 'Finance / Tax', status: 'NOT_BUILT' },
      { id: 'ENG', name: 'Engineering', status: 'NOT_BUILT' },
    ],
  };
}

function clampPercent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return undefined;
  return Math.max(0, Math.min(100, Math.round(numeric)));
}

function remainingFromUsed(usedPercent) {
  const used = clampPercent(usedPercent);
  return used === undefined ? undefined : 100 - used;
}

function sourceUnavailable(source, error) {
  return {
    available: false,
    source,
    ...(error ? { error: String(error).slice(0, 220) } : {}),
  };
}

async function findCodexBinary() {
  const candidates = [
    process.env.HERCHI26_CODEX_BIN,
    path.join(homedir(), '.local', 'bin', 'codex'),
    '/opt/homebrew/bin/codex',
    '/usr/local/bin/codex',
    '/Applications/Codex.app/Contents/Resources/codex',
  ].filter(Boolean);

  for (const directory of String(process.env.PATH ?? '').split(':').filter(Boolean)) {
    candidates.push(path.join(directory, 'codex'));
  }

  for (const candidate of candidates) {
    if (await exists(candidate)) return candidate;
  }

  const versionsRoot = '/Volumes/HERCHI26_01/HERCHI26_RUNTIME_WORK/tools/codex/versions';
  const versions = (await readDirSafe(versionsRoot, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory())
    .map((entry) => entry.name)
    .sort()
    .reverse();

  for (const version of versions) {
    const vendorRoot = path.join(versionsRoot, version, 'package', 'vendor');
    const architectures = await readDirSafe(vendorRoot, { withFileTypes: true });
    for (const architecture of architectures) {
      if (!architecture.isDirectory() || !architecture.name.includes('apple-darwin')) continue;
      const candidate = path.join(vendorRoot, architecture.name, 'bin', 'codex');
      if (await exists(candidate)) return candidate;
    }
  }

  return null;
}

function queryCodexAppServerOnce(binary, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(binary, args, {
      cwd: repoRoot,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: process.env,
    });
    let buffer = '';
    let stderr = '';
    let initialized = false;
    let settled = false;

    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { child.stdin.end(); } catch {}
      try { child.kill('SIGTERM'); } catch {}
      if (error) reject(error); else resolve(value);
    };

    const send = (message) => {
      try { child.stdin.write(`${JSON.stringify(message)}\n`); }
      catch (error) { finish(error); }
    };

    const handleLine = (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      let message;
      try { message = JSON.parse(trimmed); } catch { return; }
      if (message.id === 1 && !initialized) {
        initialized = true;
        send({ method: 'initialized', params: {} });
        send({ id: 2, method: 'account/rateLimits/read' });
        return;
      }
      if (message.id === 2) {
        if (message.error) finish(new Error(`Codex rate limits: ${message.error.message ?? 'RPC error'}`));
        else finish(null, message.result ?? {});
      }
    };

    child.stdout.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      for (;;) {
        const newline = buffer.indexOf('\n');
        if (newline < 0) break;
        const line = buffer.slice(0, newline);
        buffer = buffer.slice(newline + 1);
        handleLine(line);
      }
    });
    child.stderr.on('data', (chunk) => { stderr = `${stderr}${chunk.toString('utf8')}`.slice(-1200); });
    child.on('error', (error) => finish(error));
    child.on('exit', (code) => {
      if (!settled) finish(new Error(`Codex app-server beendet (${code ?? 'unbekannt'}): ${stderr.trim() || 'keine Antwort'}`));
    });

    const timer = setTimeout(() => finish(new Error('Codex rate-limit timeout')), 12_000);
    send({
      id: 1,
      method: 'initialize',
      params: {
        clientInfo: { name: 'herchi26-chief', title: 'HERCHI26 Chief', version: '0.10.1' },
        capabilities: { experimentalApi: true },
      },
    });
  });
}

async function queryCodexRateLimits() {
  const binary = await findCodexBinary();
  if (!binary) throw new Error('Codex CLI nicht gefunden');
  try {
    return await queryCodexAppServerOnce(binary, ['app-server', '--stdio']);
  } catch (firstError) {
    try {
      return await queryCodexAppServerOnce(binary, ['app-server']);
    } catch (secondError) {
      throw new Error(`${firstError instanceof Error ? firstError.message : firstError}; ${secondError instanceof Error ? secondError.message : secondError}`);
    }
  }
}

function collectRateLimitSnapshots(result) {
  const snapshots = [];
  if (result?.rateLimits && typeof result.rateLimits === 'object') {
    snapshots.push({ ...result.rateLimits, _mapKey: 'rateLimits' });
  }
  if (result?.rateLimitsByLimitId && typeof result.rateLimitsByLimitId === 'object') {
    for (const [key, value] of Object.entries(result.rateLimitsByLimitId)) {
      if (value && typeof value === 'object') snapshots.push({ ...value, _mapKey: key });
    }
  }
  return snapshots;
}

function snapshotName(snapshot) {
  return [snapshot?._mapKey, snapshot?.limitId, snapshot?.limitName, snapshot?.normalModelSlug]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}

function windowsOf(snapshot) {
  return [snapshot?.primary, snapshot?.secondary].filter((window) => window && typeof window === 'object');
}

function findWindow(snapshots, durationMinutes) {
  for (const snapshot of snapshots) {
    for (const window of windowsOf(snapshot)) {
      if (Number(window.windowDurationMins) === durationMinutes && Number.isFinite(Number(window.usedPercent))) {
        return window;
      }
    }
  }
  return null;
}

function mostLimitingWindow(snapshots) {
  const windows = snapshots
    .flatMap((snapshot) => windowsOf(snapshot))
    .filter((window) => Number.isFinite(Number(window.usedPercent)));
  if (!windows.length) return null;
  return windows.reduce((worst, current) => Number(current.usedPercent) > Number(worst.usedPercent) ? current : worst);
}

function resourceFromWindow(window, source) {
  const remainingPercent = window ? remainingFromUsed(window.usedPercent) : undefined;
  if (remainingPercent === undefined) return sourceUnavailable(source);
  return {
    available: true,
    remainingPercent,
    resetAt: window.resetsAt ?? null,
    source,
  };
}

async function readCodexResources() {
  const result = await queryCodexRateLimits();
  const snapshots = collectRateLimitSnapshots(result);
  const sparkSnapshots = snapshots.filter((snapshot) => snapshotName(snapshot).includes('spark'));
  const generalSnapshots = snapshots.filter((snapshot) => !snapshotName(snapshot).includes('spark'));
  const codexWindow = mostLimitingWindow(generalSnapshots.length ? generalSnapshots : snapshots);
  const sparkFiveWindow = findWindow(sparkSnapshots, 300);
  const sparkWeekWindow = findWindow(sparkSnapshots, 10_080);
  return {
    codex: resourceFromWindow(codexWindow, 'Codex App Server'),
    sparkFive: resourceFromWindow(sparkFiveWindow, 'Codex App Server · Spark'),
    sparkWeek: resourceFromWindow(sparkWeekWindow, 'Codex App Server · Spark'),
  };
}

function captureCommand(command, args, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'], env: process.env });
    let stdout = '';
    let stderr = '';
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve(value);
    };
    child.stdout.on('data', (chunk) => { stdout += chunk.toString('utf8'); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString('utf8'); });
    child.on('error', (error) => finish(error));
    child.on('exit', (code) => {
      if (code === 0) finish(null, stdout.trim());
      else finish(new Error(stderr.trim() || `${command} beendet mit ${code}`));
    });
    const timer = setTimeout(() => {
      try { child.kill('SIGTERM'); } catch {}
      finish(new Error(`${command} timeout`));
    }, timeoutMs);
  });
}

function extractClaudeAccessToken(raw) {
  if (!raw) return null;
  let parsed = raw;
  if (typeof raw === 'string') {
    try { parsed = JSON.parse(raw); }
    catch { return raw.trim() || null; }
  }
  if (!parsed || typeof parsed !== 'object') return null;
  const oauth = parsed.claudeAiOauth ?? parsed.oauth ?? parsed;
  return oauth.accessToken ?? oauth.access_token ?? null;
}

async function readClaudeAccessToken() {
  const configRoot = process.env.CLAUDE_CONFIG_DIR || path.join(homedir(), '.claude');
  const credentialFiles = [
    path.join(configRoot, '.credentials.json'),
    path.join(homedir(), '.claude', '.credentials.json'),
  ];
  for (const credentialFile of [...new Set(credentialFiles)]) {
    try {
      const raw = await fs.readFile(credentialFile, 'utf8');
      const token = extractClaudeAccessToken(raw);
      if (token) return token;
    } catch {}
  }

  try {
    const keychain = await captureCommand('/usr/bin/security', ['find-generic-password', '-s', 'Claude Code-credentials', '-w']);
    return extractClaudeAccessToken(keychain);
  } catch {
    return null;
  }
}

function claudeRemaining(window) {
  if (!window || typeof window !== 'object') return undefined;
  const utilization = Number(window.utilization);
  if (!Number.isFinite(utilization)) return undefined;
  return Math.max(0, Math.min(100, Math.round(100 - utilization)));
}

async function readClaudeResource() {
  const token = await readClaudeAccessToken();
  if (!token) throw new Error('Claude OAuth-Anmeldung nicht gefunden');
  const response = await fetch('https://api.anthropic.com/api/oauth/usage', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      'anthropic-beta': 'oauth-2025-04-20',
      'anthropic-version': '2023-06-01',
      'x-app': 'cli',
      'User-Agent': 'claude-cli/herchi26-chief',
      'Content-Type': 'application/json',
    },
    cache: 'no-store',
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Claude usage HTTP ${response.status}`);
  const usage = await response.json();
  const fiveHourRemainingPercent = claudeRemaining(usage.five_hour);
  const sevenDayRemainingPercent = claudeRemaining(usage.seven_day);
  const availableValues = [
    ['5h', fiveHourRemainingPercent, usage.five_hour?.resets_at],
    ['7d', sevenDayRemainingPercent, usage.seven_day?.resets_at],
  ].filter((entry) => typeof entry[1] === 'number');
  if (!availableValues.length) return sourceUnavailable('Claude OAuth Usage', 'Keine 5h/7d-Nutzungswerte erhalten');
  const limiting = availableValues.reduce((worst, current) => Number(current[1]) < Number(worst[1]) ? current : worst);
  return {
    available: true,
    remainingPercent: limiting[1],
    fiveHourRemainingPercent,
    sevenDayRemainingPercent,
    limitingWindow: limiting[0],
    resetAt: limiting[2] ?? null,
    source: 'Claude OAuth Usage',
  };
}

async function buildResourceStatus() {
  const checkedAt = new Date().toISOString();
  const [codexResult, claudeResult] = await Promise.allSettled([
    readCodexResources(),
    readClaudeResource(),
  ]);

  const codexError = codexResult.status === 'rejected'
    ? (codexResult.reason instanceof Error ? codexResult.reason.message : String(codexResult.reason))
    : null;
  const claudeError = claudeResult.status === 'rejected'
    ? (claudeResult.reason instanceof Error ? claudeResult.reason.message : String(claudeResult.reason))
    : null;

  return {
    checkedAt,
    cached: false,
    codex: codexResult.status === 'fulfilled' ? codexResult.value.codex : sourceUnavailable('Codex App Server', codexError),
    claude: claudeResult.status === 'fulfilled' ? claudeResult.value : sourceUnavailable('Claude OAuth Usage', claudeError),
    sparkFive: codexResult.status === 'fulfilled' ? codexResult.value.sparkFive : sourceUnavailable('Codex App Server · Spark', codexError),
    sparkWeek: codexResult.status === 'fulfilled' ? codexResult.value.sparkWeek : sourceUnavailable('Codex App Server · Spark', codexError),
  };
}

async function getResourceStatus(force = false) {
  if (!force && resourceCache && Date.now() - resourceCacheAt < RESOURCE_CACHE_MS) {
    return { ...resourceCache, cached: true };
  }
  if (resourceRefreshInFlight) return resourceRefreshInFlight;
  resourceRefreshInFlight = buildResourceStatus()
    .then((status) => {
      resourceCache = status;
      resourceCacheAt = Date.now();
      return status;
    })
    .finally(() => { resourceRefreshInFlight = null; });
  return resourceRefreshInFlight;
}

async function updateStatusResponse() {
  try {
    return await checkForUpdate(repoRoot);
  } catch (error) {
    let current = null;
    try { current = await readCurrentVersion(repoRoot); } catch {}
    return {
      current,
      available: null,
      updateAvailable: false,
      channelConfigured: false,
      state: 'ERROR',
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function beginUpdate(response) {
  if (updateApplying) {
    sendJson(response, 409, { error: 'UPDATE_ALREADY_RUNNING' });
    return;
  }
  updateApplying = true;
  try {
    const prepared = await prepareUpdate(repoRoot);
    const child = spawn(node, [
      applyUpdateScript,
      '--runtime', repoRoot,
      '--archive', prepared.archive,
      '--version', String(prepared.available.version),
      '--parent-pid', String(process.pid),
      '--browser', '1',
    ], {
      cwd: repoRoot,
      detached: true,
      stdio: 'ignore',
      env: process.env,
    });
    child.unref();
    sendJson(response, 202, {
      accepted: true,
      state: 'APPLYING',
      current: prepared.current,
      available: prepared.available,
      sha256: prepared.sha256,
      message: 'Update verifiziert. HERCHI26 wird neu gestartet.',
    });
    setTimeout(() => {
      stop();
      process.exit(0);
    }, 350);
  } catch (error) {
    updateApplying = false;
    sendJson(response, 409, {
      error: error instanceof Error ? error.message : String(error),
      ...(await updateStatusResponse()),
    });
  }
}

const runtimeServer = http.createServer(async (request, response) => {
  if (request.method === 'OPTIONS') {
    response.writeHead(204, corsHeaders);
    response.end();
    return;
  }

  const requestUrl = new URL(request.url ?? '/', `http://127.0.0.1:${RUNTIME_PORT}`);

  if (request.method === 'GET' && requestUrl.pathname === '/health') {
    sendJson(response, 200, { status: 'ONLINE', updateApplying, checkedAt: new Date().toISOString() });
    return;
  }

  if (request.method === 'GET' && requestUrl.pathname === '/v1/status') {
    sendJson(response, 200, await getRuntimeStatus());
    return;
  }

  if (request.method === 'GET' && requestUrl.pathname === '/v1/resources') {
    const force = requestUrl.searchParams.get('refresh') === '1';
    sendJson(response, 200, await getResourceStatus(force));
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/start-all') {
    await ensureComms();
    await ensureChief();
    sendJson(response, 200, await getRuntimeStatus());
    return;
  }

  if ((request.method === 'GET' || request.method === 'POST') && requestUrl.pathname === '/v1/update/status') {
    sendJson(response, 200, await updateStatusResponse());
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/update/channel') {
    try {
      const body = await readJson(request);
      if (!body.manifestUrl || typeof body.manifestUrl !== 'string') {
        sendJson(response, 400, { error: 'manifestUrl required' });
        return;
      }
      const channel = await setUpdateChannelConfig(body.manifestUrl.trim());
      sendJson(response, 200, { saved: true, channel, status: await updateStatusResponse() });
    } catch (error) {
      sendJson(response, 400, { error: error instanceof Error ? error.message : String(error) });
    }
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/update/apply') {
    await beginUpdate(response);
    return;
  }

  sendJson(response, 404, { error: 'NOT_FOUND' });
});

function stop() {
  if (stopping) return;
  stopping = true;
  if (communication && communication.exitCode === null) communication.kill('SIGTERM');
  if (chief && chief.exitCode === null) chief.kill('SIGTERM');
  runtimeServer.close();
}

process.on('SIGINT', () => {
  stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  stop();
  process.exit(0);
});

runtimeServer.listen(RUNTIME_PORT, '127.0.0.1', async () => {
  console.log(`HERCHI26 Runtime V1 listening on http://127.0.0.1:${RUNTIME_PORT}`);
  await ensureComms();
  await ensureChief();
  const status = await getRuntimeStatus();
  console.log('HERCHI26 V1 runtime ready:', JSON.stringify(status));
});
