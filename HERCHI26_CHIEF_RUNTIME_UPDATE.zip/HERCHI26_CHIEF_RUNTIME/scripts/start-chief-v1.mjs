import http from 'node:http';
import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import {
  checkForUpdate,
  prepareUpdate,
  readCurrentVersion,
  setUpdateChannelConfig,
} from './update-core-v1.mjs';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const node = process.execPath;
const viteCli = path.join(repoRoot, 'apps', 'chief-v1', 'node_modules', 'vite', 'bin', 'vite.js');
const staticChiefScript = path.join(repoRoot, 'scripts', 'serve-chief-v1.mjs');
const staticChiefIndex = path.join(repoRoot, 'apps', 'chief-v1', 'dist', 'index.html');
const applyUpdateScript = path.join(repoRoot, 'scripts', 'apply-update-v1.mjs');
const RUNTIME_PORT = 4259;
const CHIEF_URL = 'http://127.0.0.1:4260';
const COMMS_URL = 'http://127.0.0.1:4261';

let chief = null;
let communication = null;
let stopping = false;
let updateApplying = false;

const corsHeaders = {
  'Access-Control-Allow-Origin': 'http://127.0.0.1:4260',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, {
    ...corsHeaders,
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(JSON.stringify(body));
}

async function readJson(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

async function exists(file) {
  try { await fs.access(file); return true; } catch { return false; }
}

async function isHttpOk(url) {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(700) });
    return response.ok;
  } catch {
    return false;
  }
}

async function waitUntilOnline(url, attempts = 30) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await isHttpOk(url)) return true;
    await sleep(150);
  }
  return false;
}

function watchChild(name, child) {
  child.on('exit', (code) => {
    if (!stopping && code && code !== 0) console.error(`${name} stopped with code ${code}`);
    if (name === 'COMMS') communication = null;
    if (name === 'CORE') chief = null;
  });
}

async function ensureComms() {
  if (await isHttpOk(`${COMMS_URL}/health`)) return;
  if (communication && communication.exitCode === null) return;

  communication = spawn(node, ['apps/communication-v1/server.mjs'], {
    cwd: repoRoot,
    stdio: 'inherit',
    env: process.env,
  });
  watchChild('COMMS', communication);
  await waitUntilOnline(`${COMMS_URL}/health`);
}

async function ensureChief() {
  if (await isHttpOk(CHIEF_URL)) return;
  if (chief && chief.exitCode === null) return;

  const productionBuildExists = await exists(staticChiefIndex);
  const args = productionBuildExists
    ? [staticChiefScript]
    : [viteCli, '--host', '127.0.0.1', '--port', '4260'];
  const cwd = productionBuildExists ? repoRoot : path.join(repoRoot, 'apps', 'chief-v1');

  chief = spawn(node, args, {
    cwd,
    stdio: 'inherit',
    env: process.env,
  });
  watchChild('CORE', chief);
  await waitUntilOnline(CHIEF_URL, 50);
}

async function getRuntimeStatus() {
  const [chiefOnline, commsOnline] = await Promise.all([
    isHttpOk(CHIEF_URL),
    isHttpOk(`${COMMS_URL}/health`),
  ]);
  let version = null;
  try { version = await readCurrentVersion(repoRoot); } catch {}

  return {
    runtime: 'ONLINE',
    checkedAt: new Date().toISOString(),
    version,
    updateApplying,
    services: [
      { id: 'CORE', name: 'Chief Platform', status: chiefOnline ? 'ONLINE' : 'OFFLINE', endpoint: CHIEF_URL },
      { id: 'COMMS', name: 'Mail & Kommunikation', status: commsOnline ? 'ONLINE' : 'OFFLINE', endpoint: COMMS_URL },
      { id: 'SEA', name: 'SEA', status: 'NOT_BUILT' },
      { id: 'FIN', name: 'Finance / Tax', status: 'NOT_BUILT' },
      { id: 'ENG', name: 'Engineering', status: 'NOT_BUILT' },
    ],
  };
}

async function updateStatusResponse() {
  try {
    return await checkForUpdate(repoRoot);
  } catch (error) {
    let current = null;
    try { current = await readCurrentVersion(repoRoot); } catch {}
    return {
      current,
      available: null,
      updateAvailable: false,
      channelConfigured: false,
      state: 'ERROR',
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function beginUpdate(response) {
  if (updateApplying) {
    sendJson(response, 409, { error: 'UPDATE_ALREADY_RUNNING' });
    return;
  }
  updateApplying = true;
  try {
    const prepared = await prepareUpdate(repoRoot);
    const child = spawn(node, [
      applyUpdateScript,
      '--runtime', repoRoot,
      '--archive', prepared.archive,
      '--version', String(prepared.available.version),
      '--parent-pid', String(process.pid),
      '--browser', '1',
    ], {
      cwd: repoRoot,
      detached: true,
      stdio: 'ignore',
      env: process.env,
    });
    child.unref();
    sendJson(response, 202, {
      accepted: true,
      state: 'APPLYING',
      current: prepared.current,
      available: prepared.available,
      sha256: prepared.sha256,
      message: 'Update verifiziert. HERCHI26 wird neu gestartet.',
    });
    setTimeout(() => {
      stop();
      process.exit(0);
    }, 350);
  } catch (error) {
    updateApplying = false;
    sendJson(response, 409, {
      error: error instanceof Error ? error.message : String(error),
      ...(await updateStatusResponse()),
    });
  }
}

const runtimeServer = http.createServer(async (request, response) => {
  if (request.method === 'OPTIONS') {
    response.writeHead(204, corsHeaders);
    response.end();
    return;
  }

  const requestUrl = new URL(request.url ?? '/', `http://127.0.0.1:${RUNTIME_PORT}`);

  if (request.method === 'GET' && requestUrl.pathname === '/health') {
    sendJson(response, 200, { status: 'ONLINE', updateApplying, checkedAt: new Date().toISOString() });
    return;
  }

  if (request.method === 'GET' && requestUrl.pathname === '/v1/status') {
    sendJson(response, 200, await getRuntimeStatus());
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/start-all') {
    await ensureComms();
    await ensureChief();
    sendJson(response, 200, await getRuntimeStatus());
    return;
  }

  if ((request.method === 'GET' || request.method === 'POST') && requestUrl.pathname === '/v1/update/status') {
    sendJson(response, 200, await updateStatusResponse());
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/update/channel') {
    try {
      const body = await readJson(request);
      if (!body.manifestUrl || typeof body.manifestUrl !== 'string') {
        sendJson(response, 400, { error: 'manifestUrl required' });
        return;
      }
      const channel = await setUpdateChannelConfig(body.manifestUrl.trim());
      sendJson(response, 200, { saved: true, channel, status: await updateStatusResponse() });
    } catch (error) {
      sendJson(response, 400, { error: error instanceof Error ? error.message : String(error) });
    }
    return;
  }

  if (request.method === 'POST' && requestUrl.pathname === '/v1/update/apply') {
    await beginUpdate(response);
    return;
  }

  sendJson(response, 404, { error: 'NOT_FOUND' });
});

function stop() {
  if (stopping) return;
  stopping = true;
  if (communication && communication.exitCode === null) communication.kill('SIGTERM');
  if (chief && chief.exitCode === null) chief.kill('SIGTERM');
  runtimeServer.close();
}

process.on('SIGINT', () => {
  stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  stop();
  process.exit(0);
});

runtimeServer.listen(RUNTIME_PORT, '127.0.0.1', async () => {
  console.log(`HERCHI26 Runtime V1 listening on http://127.0.0.1:${RUNTIME_PORT}`);
  await ensureComms();
  await ensureChief();
  const status = await getRuntimeStatus();
  console.log('HERCHI26 V1 runtime ready:', JSON.stringify(status));
});
