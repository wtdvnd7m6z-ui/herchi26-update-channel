import { execFileSync } from 'node:child_process';
import { chmod, cp, mkdir, rm, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateSync } from 'node:zlib';

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const buildRoot = path.join(repoRoot, 'dist', 'mac');
const appName = 'HERCHI26 Chief.app';
const builtApp = path.join(buildRoot, appName);
const contents = path.join(builtApp, 'Contents');
const macos = path.join(contents, 'MacOS');
const resources = path.join(contents, 'Resources');
const installRequested = process.argv.includes('--install');
const installDir = path.join(homedir(), 'Applications');
const installedApp = path.join(installDir, appName);
const nodeExecutable = process.execPath;

const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key>
  <string>de</string>
  <key>CFBundleDisplayName</key>
  <string>HERCHI26 Chief</string>
  <key>CFBundleExecutable</key>
  <string>herchi26-chief</string>
  <key>CFBundleIdentifier</key>
  <string>de.herchi26.chief.v1</string>
  <key>CFBundleIconFile</key>
  <string>HERCHI26Chief</string>
  <key>CFBundleInfoDictionaryVersion</key>
  <string>6.0</string>
  <key>CFBundleName</key>
  <string>HERCHI26 Chief</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleShortVersionString</key>
  <string>1.1</string>
  <key>CFBundleVersion</key>
  <string>2</string>
  <key>LSMinimumSystemVersion</key>
  <string>12.0</string>
  <key>NSHighResolutionCapable</key>
  <true/>
  <key>LSUIElement</key>
  <false/>
</dict>
</plist>
`;

const launcher = `#!/bin/zsh
set -e
REPO_ROOT=${JSON.stringify(repoRoot)}
NODE_BIN=${JSON.stringify(nodeExecutable)}
LOG_DIR="$HOME/Library/Logs"
LOG_FILE="$LOG_DIR/HERCHI26-Chief.log"
mkdir -p "$LOG_DIR"
cd "$REPO_ROOT"
"$NODE_BIN" scripts/launch-herchi26-v1.mjs >>"$LOG_FILE" 2>&1
`;

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBuffer = Buffer.from(type, 'ascii');
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const crcInput = Buffer.concat([typeBuffer, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcInput), 0);
  return Buffer.concat([length, typeBuffer, data, crc]);
}

function createChiefIconPng(size = 1024) {
  const pixels = Buffer.alloc(size * size * 4, 0);

  function setPixel(x, y, r, g, b, a = 255) {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const offset = (y * size + x) * 4;
    pixels[offset] = r;
    pixels[offset + 1] = g;
    pixels[offset + 2] = b;
    pixels[offset + 3] = a;
  }

  function insideRoundedRect(x, y, left, top, right, bottom, radius) {
    if (x >= left + radius && x <= right - radius && y >= top && y <= bottom) return true;
    if (y >= top + radius && y <= bottom - radius && x >= left && x <= right) return true;
    const corners = [
      [left + radius, top + radius],
      [right - radius, top + radius],
      [left + radius, bottom - radius],
      [right - radius, bottom - radius],
    ];
    return corners.some(([cx, cy]) => ((x - cx) ** 2 + (y - cy) ** 2) <= radius ** 2);
  }

  const margin = 64;
  const radius = 210;
  for (let y = margin; y < size - margin; y += 1) {
    for (let x = margin; x < size - margin; x += 1) {
      if (!insideRoundedRect(x, y, margin, margin, size - margin - 1, size - margin - 1, radius)) continue;
      const t = (y - margin) / (size - margin * 2);
      setPixel(x, y, 7 + Math.round(5 * t), 22 + Math.round(14 * t), 40 + Math.round(25 * t), 255);
    }
  }

  const cx = size / 2;
  const cy = 480;
  for (let y = 170; y < 800; y += 1) {
    for (let x = 170; x < 855; x += 1) {
      const dx = (x - cx) / 340;
      const dy = (y - cy) / 310;
      const d = dx * dx + dy * dy;
      if (d <= 1.0) setPixel(x, y, 13, 50, 83, 255);
      if (d > 0.88 && d <= 1.0) setPixel(x, y, 40, 126, 214, 255);
    }
  }

  const glyphs = {
    H: ['10001','10001','10001','11111','10001','10001','10001'],
    '2': ['11110','00001','00001','11110','10000','10000','11111'],
    '6': ['01111','10000','10000','11110','10001','10001','01110'],
  };

  function drawGlyph(pattern, x0, y0, scale, color) {
    for (let row = 0; row < pattern.length; row += 1) {
      for (let col = 0; col < pattern[row].length; col += 1) {
        if (pattern[row][col] !== '1') continue;
        for (let y = 0; y < scale; y += 1) {
          for (let x = 0; x < scale; x += 1) {
            setPixel(x0 + col * scale + x, y0 + row * scale + y, ...color);
          }
        }
      }
    }
  }

  const scale = 42;
  const glyphWidth = 5 * scale;
  const gap = 28;
  const totalWidth = glyphWidth * 3 + gap * 2;
  let gx = Math.round((size - totalWidth) / 2);
  const gy = 320;
  drawGlyph(glyphs.H, gx, gy, scale, [239, 247, 255, 255]);
  gx += glyphWidth + gap;
  drawGlyph(glyphs['2'], gx, gy, scale, [239, 247, 255, 255]);
  gx += glyphWidth + gap;
  drawGlyph(glyphs['6'], gx, gy, scale, [239, 247, 255, 255]);

  for (let y = 650; y < 686; y += 1) {
    for (let x = 300; x < 724; x += 1) {
      setPixel(x, y, 59, 169, 255, 255);
    }
  }

  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y += 1) {
    const rowOffset = y * (size * 4 + 1);
    raw[rowOffset] = 0;
    pixels.copy(raw, rowOffset + 1, y * size * 4, (y + 1) * size * 4);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    Buffer.from([137,80,78,71,13,10,26,10]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

async function buildMacIcon() {
  const sourcePng = path.join(resources, 'HERCHI26Chief-1024.png');
  await writeFile(sourcePng, createChiefIconPng(1024));

  if (process.platform !== 'darwin') return;

  const iconset = path.join(buildRoot, 'HERCHI26Chief.iconset');
  await rm(iconset, { recursive: true, force: true });
  await mkdir(iconset, { recursive: true });

  const sizes = [
    [16, 'icon_16x16.png'],
    [32, 'icon_16x16@2x.png'],
    [32, 'icon_32x32.png'],
    [64, 'icon_32x32@2x.png'],
    [128, 'icon_128x128.png'],
    [256, 'icon_128x128@2x.png'],
    [256, 'icon_256x256.png'],
    [512, 'icon_256x256@2x.png'],
    [512, 'icon_512x512.png'],
    [1024, 'icon_512x512@2x.png'],
  ];

  for (const [pixels, filename] of sizes) {
    execFileSync('/usr/bin/sips', ['-z', String(pixels), String(pixels), sourcePng, '--out', path.join(iconset, filename)], {
      stdio: 'ignore',
    });
  }

  execFileSync('/usr/bin/iconutil', ['-c', 'icns', iconset, '-o', path.join(resources, 'HERCHI26Chief.icns')], {
    stdio: 'ignore',
  });
  await rm(iconset, { recursive: true, force: true });
}

await rm(builtApp, { recursive: true, force: true });
await mkdir(macos, { recursive: true });
await mkdir(resources, { recursive: true });
await writeFile(path.join(contents, 'Info.plist'), plist, 'utf8');
await writeFile(path.join(macos, 'herchi26-chief'), launcher, 'utf8');
await chmod(path.join(macos, 'herchi26-chief'), 0o755);
await buildMacIcon();

if (installRequested) {
  await mkdir(installDir, { recursive: true });
  await rm(installedApp, { recursive: true, force: true });
  await cp(builtApp, installedApp, { recursive: true });
  console.log(`INSTALLED ${installedApp}`);
  console.log(`NODE ${nodeExecutable}`);
} else {
  console.log(`BUILT ${builtApp}`);
}
