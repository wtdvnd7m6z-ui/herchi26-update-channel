const tabs = document.querySelectorAll('[data-tab]');
const panels = document.querySelectorAll('.tab-panel');
const toast = document.getElementById('toast');
const serviceStatus = document.getElementById('serviceStatus');

const mailState = {
  folder: 'INBOX',
  messages: [],
  selectedId: null,
  detail: null,
  folders: [],
  composeMode: 'new',
  composeMessageId: null,
};

function showToast(message, duration = 3200) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), duration);
}

function openTab(name) {
  tabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.tab === name));
  panels.forEach((panel) => panel.classList.toggle('active', panel.id === name));
  if (name === 'mail') {
    void loadFolders();
    void loadMailWorkspace();
    void loadHandoffs();
  }
}

tabs.forEach((tab) => tab.addEventListener('click', () => openTab(tab.dataset.tab)));
document.querySelectorAll('[data-tab-jump]').forEach((button) => button.addEventListener('click', () => openTab(button.dataset.tabJump)));

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' })[char]);
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('de-DE', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' }).format(date);
}

function splitAddresses(value) {
  return String(value ?? '').split(/[;,]/).map((entry) => entry.trim()).filter(Boolean);
}

async function api(url, options = {}) {
  const response = await fetch(url, { cache:'no-store', ...options });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message ?? payload.error ?? `HTTP ${response.status}`);
  return payload;
}

function renderOverviewMessages(messages) {
  const root = document.getElementById('overviewMailContent');
  if (!root) return;
  if (!messages.length) {
    root.outerHTML = '<div id="overviewMailContent" class="empty-live-state"><strong>Inbox ist leer</strong></div>';
    return;
  }
  root.outerHTML = `<div id="overviewMailContent" class="mail-list">${messages.slice(0,5).map((m) => `
    <button class="mail-item compact ${m.isRead ? '' : 'unread'}" data-overview-mail-id="${escapeHtml(m.id)}">
      <div class="mail-item-head"><strong>${escapeHtml(m.sender || m.from?.name || 'Unbekannt')}</strong><span>${escapeHtml(formatDate(m.receivedDateTime))}</span></div>
      <div class="mail-subject">${escapeHtml(m.subject)}</div>
    </button>`).join('')}</div>`;
  document.querySelectorAll('[data-overview-mail-id]').forEach((button) => button.addEventListener('click', () => {
    mailState.folder = 'INBOX';
    openTab('mail');
    setTimeout(() => void openMessage(button.dataset.overviewMailId), 0);
  }));
}

function renderMailList(messages) {
  const root = document.getElementById('mailMessageList');
  const caption = document.getElementById('mailListStatus');
  if (caption) caption.textContent = `${messages.length} Nachrichten`;
  if (!root) return;
  if (!messages.length) {
    root.innerHTML = '<div class="empty-live-state"><strong>Keine Nachrichten gefunden</strong><p>Ordner oder Suche ändern.</p></div>';
    return;
  }
  root.innerHTML = messages.map((m) => `
    <button class="mail-row ${m.isRead ? '' : 'unread'} ${m.id === mailState.selectedId ? 'selected' : ''}" data-mail-id="${escapeHtml(m.id)}">
      <div class="mail-row-top"><strong>${escapeHtml(m.sender || 'Unbekannt')}</strong><span>${escapeHtml(formatDate(m.receivedDateTime))}</span></div>
      <div class="mail-row-subject">${m.isFlagged ? '★ ' : ''}${escapeHtml(m.subject)}</div>
      <div class="mail-row-meta">${m.attachmentCount ? `📎 ${m.attachmentCount}` : ''}${m.isRead ? '' : '<span>NEU</span>'}</div>
    </button>`).join('');
  root.querySelectorAll('[data-mail-id]').forEach((button) => button.addEventListener('click', () => void openMessage(button.dataset.mailId)));
}

function detailActions(message) {
  return `
    <div class="mail-detail-actions">
      <button class="primary-button" data-detail-action="reply">↩ Antworten</button>
      <button class="secondary-button" data-detail-action="replyAll">↩↩ Allen antworten</button>
      <button class="secondary-button" data-detail-action="forward">↪ Weiterleiten</button>
      <button class="secondary-button" data-detail-action="${message.isRead ? 'unread' : 'read'}">${message.isRead ? 'Ungelesen' : 'Gelesen'}</button>
      <button class="secondary-button" data-detail-action="${message.isFlagged ? 'unflag' : 'flag'}">${message.isFlagged ? '★ Markierung aus' : '☆ Markieren'}</button>
      <button class="secondary-button" data-detail-action="archive">Archivieren</button>
      <select id="detailMoveTarget"><option value="">Verschieben nach …</option>${mailState.folders.map((f) => `<option value="${escapeHtml(f.name)}">${escapeHtml(f.name)}</option>`).join('')}</select>
      <button class="secondary-button" data-detail-action="move">Verschieben</button>
      <button class="danger-button" data-detail-action="delete">Löschen</button>
    </div>`;
}

function renderDetail(message) {
  const root = document.getElementById('mailDetailPane');
  if (!root) return;
  const attachments = message.attachments?.length
    ? `<div class="attachment-block"><strong>Anhänge</strong><div class="attachment-chips">${message.attachments.map((a) => `<span>📎 ${escapeHtml(a.name)}${a.size ? ` · ${Math.round(a.size/1024)} KB` : ''}</span>`).join('')}</div><button class="secondary-button" data-detail-action="saveAttachments">Anhänge lokal speichern</button></div>`
    : '';
  root.innerHTML = `
    <div class="mail-detail-head"><div><small>${escapeHtml(message.sender || '')}</small><h2>${escapeHtml(message.subject)}</h2><p>${escapeHtml(formatDate(message.receivedDateTime))}</p></div><span class="mail-detail-state">${message.isRead ? 'Gelesen' : 'Ungelesen'}</span></div>
    ${detailActions(message)}
    <div class="handoff-actions"><span>Weitergeben:</span><button class="handoff-button support" data-detail-action="handoffSupport">Support</button><button class="handoff-button finance" data-detail-action="handoffFinance">Rechnung / Finance</button></div>
    ${attachments}
    <pre class="mail-content">${escapeHtml(message.content || '')}</pre>`;
  root.querySelectorAll('[data-detail-action]').forEach((button) => button.addEventListener('click', () => void handleDetailAction(button.dataset.detailAction)));
}

async function loadStatus({ toastResult = false } = {}) {
  if (serviceStatus) serviceStatus.textContent = 'Prüfe …';
  try {
    const status = await api('/v1/mail/status');
    if (serviceStatus) serviceStatus.textContent = 'OK';
    const connected = Boolean(status.exchange?.connected);
    const account = status.account?.address || status.account?.displayName || '—';
    const unread = status.unread ?? '—';
    const total = status.total ?? '—';
    document.getElementById('exchangeAccountRow')?.classList.toggle('warning-row', !connected);
    const statusText = document.getElementById('exchangeStatusText');
    if (statusText) statusText.innerHTML = connected ? '<i class="dot ok"></i>Verbunden' : '<i class="dot error"></i>Nicht verbunden';
    const sub = document.getElementById('exchangeStatusSub'); if (sub) sub.textContent = connected ? account : 'Apple Mail lokal prüfen';
    const unreadEl = document.getElementById('exchangeUnread'); if (unreadEl) unreadEl.textContent = connected ? unread : '—';
    const metricUnread = document.getElementById('metricUnread'); if (metricUnread) metricUnread.textContent = connected ? unread : '—';
    const inbox = document.getElementById('metricInbox'); if (inbox) inbox.textContent = connected ? total : '—';
    const user = document.getElementById('exchangeUser'); if (user) user.textContent = connected ? account : '—';
    const mailbox = document.getElementById('exchangeMailboxTotal'); if (mailbox) mailbox.textContent = connected ? `${total} Inbox` : '—';
    const sync = document.getElementById('exchangeLastSync'); if (sync) sync.textContent = connected ? formatDate(status.lastSync) : '—';
    const detail = document.getElementById('exchangeDetailStatus'); if (detail) { detail.textContent = connected ? '● Verbunden' : '● Nicht verbunden'; detail.className = connected ? 'ok-text' : 'error-text'; }
    const access = document.getElementById('exchangeGraphState'); if (access) { access.textContent = '● Nur lokal'; access.className = connected ? 'ok-text' : ''; }
    const warningTitle = document.getElementById('exchangeWarningTitle'); if (warningTitle) warningTitle.textContent = connected ? 'Exchange ist lokal verbunden' : 'Apple Mail lokal prüfen';
    const warningText = document.getElementById('exchangeWarningText'); if (warningText) warningText.textContent = connected ? `HERCHI26 arbeitet lokal mit ${account}.` : 'Apple Mail Zugriff einmalig erlauben.';
    const systemDot = document.getElementById('systemExchangeDot'); if (systemDot) systemDot.className = connected ? 'dot ok' : 'dot error';
    const systemText = document.getElementById('systemExchangeStatus'); if (systemText) { systemText.textContent = connected ? 'Verbunden' : 'Nicht verbunden'; systemText.className = connected ? 'ok-text' : 'error-text'; }
    const setting = document.getElementById('localExchangeSetting'); if (setting) setting.textContent = connected ? 'Verbunden' : 'Nicht verbunden';
    const setup = document.getElementById('graphSetupStatus'); if (setup) { setup.textContent = connected ? 'Verbunden' : 'Nicht verbunden'; setup.className = connected ? 'ok-text' : 'error-text'; }
    document.getElementById('connectExchange').textContent = connected ? 'Apple Mail verbunden' : 'Apple Mail erlauben';
    document.getElementById('connectGraph').textContent = connected ? 'Apple Mail verbunden' : 'Apple Mail Zugriff prüfen';
    if (connected) {
      const inboxPayload = await api('/v1/mail/messages?folder=INBOX&limit=10');
      renderOverviewMessages(inboxPayload.messages ?? []);
    }
    if (toastResult) showToast(connected ? 'Exchange ist lokal verbunden.' : 'Exchange ist noch nicht verbunden.');
    return status;
  } catch (error) {
    if (serviceStatus) serviceStatus.textContent = 'Fehler';
    if (toastResult) showToast(error.message);
    return null;
  }
}

async function connectAppleMail() {
  try {
    await api('/v1/mail/local/connect', { method:'POST' });
    showToast('Apple Mail / Exchange ist lokal verbunden.');
    await loadStatus();
  } catch (error) {
    showToast(`${error.message} Falls macOS fragt: Mail-Zugriff bitte erlauben.`, 5200);
  }
}

async function loadFolders() {
  try {
    const payload = await api('/v1/mail/folders');
    mailState.folders = payload.folders ?? [];
  } catch {
    mailState.folders = [];
  }
}

async function loadMailWorkspace(query = '') {
  const folder = document.getElementById('mailFolder')?.value || mailState.folder;
  mailState.folder = folder;
  try {
    const payload = await api(`/v1/mail/messages?folder=${encodeURIComponent(folder)}&limit=60&q=${encodeURIComponent(query)}`);
    mailState.messages = payload.messages ?? [];
    renderMailList(mailState.messages);
  } catch (error) {
    showToast(error.message);
  }
}

async function openMessage(id) {
  mailState.selectedId = id;
  renderMailList(mailState.messages);
  try {
    const payload = await api(`/v1/mail/message?folder=${encodeURIComponent(mailState.folder)}&id=${encodeURIComponent(id)}`);
    mailState.detail = payload.message;
    renderDetail(payload.message);
  } catch (error) {
    showToast(error.message);
  }
}

async function mailAction(action, extra = {}) {
  if (!mailState.selectedId) return;
  await api('/v1/mail/action', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ id:mailState.selectedId, folder:mailState.folder, action, ...extra }) });
}

async function handleDetailAction(action) {
  if (!mailState.detail) return;
  try {
    if (['reply','replyAll','forward'].includes(action)) {
      openCompose(action, mailState.detail.id);
      return;
    }
    if (action === 'saveAttachments') {
      const payload = await api('/v1/mail/attachments/save', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id:mailState.detail.id,folder:mailState.folder}) });
      showToast(`${payload.files?.length ?? 0} Anhang/Anhänge gespeichert.`);
      return;
    }
    if (action === 'handoffSupport' || action === 'handoffFinance') {
      const target = action === 'handoffSupport' ? 'SUPPORT' : 'FINANCE';
      const payload = await api('/v1/mail/handoff', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id:mailState.detail.id,folder:mailState.folder,target}) });
      showToast(`${target === 'SUPPORT' ? 'Support' : 'Finance'}-Übergabe ${payload.handoff.id} vorbereitet.`);
      await loadHandoffs();
      return;
    }
    if (action === 'move') {
      const targetFolder = document.getElementById('detailMoveTarget')?.value;
      if (!targetFolder) { showToast('Bitte Zielordner auswählen.'); return; }
      await mailAction('move',{targetFolder});
      showToast(`E-Mail nach ${targetFolder} verschoben.`);
      mailState.selectedId = null; mailState.detail = null;
      document.getElementById('mailDetailPane').innerHTML = '<div class="mail-detail-empty"><strong>E-Mail verschoben</strong></div>';
      await loadMailWorkspace();
      return;
    }
    if (action === 'delete' && !window.confirm('Diese E-Mail wirklich in Apple Mail löschen?')) return;
    await mailAction(action);
    showToast(`Aktion „${action}“ ausgeführt.`);
    if (['archive','delete'].includes(action)) {
      mailState.selectedId = null; mailState.detail = null;
      document.getElementById('mailDetailPane').innerHTML = '<div class="mail-detail-empty"><strong>Aktion ausgeführt</strong></div>';
      await loadMailWorkspace();
    } else {
      await loadMailWorkspace();
      await openMessage(mailState.selectedId);
    }
    await loadStatus();
  } catch (error) {
    showToast(error.message, 5000);
  }
}

function openCompose(mode = 'new', messageId = null) {
  mailState.composeMode = mode;
  mailState.composeMessageId = messageId;
  const overlay = document.getElementById('composeOverlay');
  overlay?.classList.remove('hidden');
  overlay?.setAttribute('aria-hidden','false');
  const recipients = document.getElementById('composeRecipients');
  const title = document.getElementById('composeTitle');
  const modeLabel = document.getElementById('composeModeLabel');
  const to = document.getElementById('composeTo');
  const cc = document.getElementById('composeCc');
  const subject = document.getElementById('composeSubject');
  const body = document.getElementById('composeBody');
  [to,cc,subject,body].forEach((el) => { if (el) el.value = ''; });
  if (mode === 'new') { title.textContent='Neue E-Mail'; modeLabel.textContent='Neue Nachricht'; recipients?.classList.remove('response-mode'); }
  else if (mode === 'forward') { title.textContent='Weiterleiten'; modeLabel.textContent=mailState.detail?.subject ?? ''; recipients?.classList.remove('response-mode'); if(subject)subject.value=`Fwd: ${mailState.detail?.subject ?? ''}`; }
  else { title.textContent=mode==='replyAll'?'Allen antworten':'Antworten'; modeLabel.textContent=mailState.detail?.subject ?? ''; recipients?.classList.add('response-mode'); }
}

function closeCompose() {
  const overlay = document.getElementById('composeOverlay');
  overlay?.classList.add('hidden');
  overlay?.setAttribute('aria-hidden','true');
}

async function submitCompose(send) {
  const bodyText = document.getElementById('composeBody')?.value ?? '';
  try {
    if (mailState.composeMode === 'new') {
      await api('/v1/mail/compose', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({to:splitAddresses(document.getElementById('composeTo')?.value),cc:splitAddresses(document.getElementById('composeCc')?.value),bcc:[],subject:document.getElementById('composeSubject')?.value ?? '',body:bodyText,send}) });
    } else {
      await api('/v1/mail/respond', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id:mailState.composeMessageId,folder:mailState.folder,mode:mailState.composeMode,body:bodyText,send,to:splitAddresses(document.getElementById('composeTo')?.value),cc:splitAddresses(document.getElementById('composeCc')?.value)}) });
    }
    showToast(send ? 'E-Mail wurde an Apple Mail zum Versand übergeben.' : 'Entwurf wurde in Apple Mail geöffnet.', 4200);
    closeCompose();
    setTimeout(() => void loadMailWorkspace(), 1000);
  } catch (error) {
    showToast(error.message, 5200);
  }
}

async function loadHandoffs() {
  try {
    const payload = await api('/v1/mail/handoffs');
    const rows = payload.handoffs ?? [];
    const count = document.getElementById('handoffCount'); if (count) count.textContent = String(rows.length);
    const metric = document.getElementById('metricHandoffs'); if (metric) metric.textContent = String(rows.length);
    const root = document.getElementById('handoffList');
    if (!root) return;
    root.innerHTML = rows.length ? rows.slice(0,10).map((row) => `<article class="handoff-row"><span class="handoff-target ${row.target.toLowerCase()}">${escapeHtml(row.target)}</span><div><strong>${escapeHtml(row.message?.subject || '')}</strong><small>${escapeHtml(row.message?.sender || '')}</small></div><span>${escapeHtml(formatDate(row.createdAt))}</span></article>`).join('') : '<div class="empty-live-state"><strong>Noch keine Übergaben</strong><p>Support- und Rechnungsübergaben erscheinen hier.</p></div>';
  } catch {}
}

['checkConnection','quickCheck','systemCheck','saveGraphConfig'].forEach((id) => document.getElementById(id)?.addEventListener('click', () => void loadStatus({toastResult:true})));
['connectGraph','connectExchange'].forEach((id) => document.getElementById(id)?.addEventListener('click', () => void connectAppleMail()));
['newMailButton','newMailOverview'].forEach((id) => document.getElementById(id)?.addEventListener('click', () => { openTab('mail'); openCompose('new'); }));

document.getElementById('mailFolder')?.addEventListener('change', () => { mailState.selectedId=null; mailState.detail=null; document.getElementById('mailDetailPane').innerHTML='<div class="mail-detail-empty"><strong>E-Mail auswählen</strong></div>'; void loadMailWorkspace(); });
document.getElementById('mailSearchButton')?.addEventListener('click', () => void loadMailWorkspace(document.getElementById('mailSearch')?.value ?? ''));
document.getElementById('mailSearch')?.addEventListener('keydown', (event) => { if(event.key==='Enter'){event.preventDefault();void loadMailWorkspace(event.currentTarget.value);} });
document.getElementById('refreshMessages')?.addEventListener('click', () => void loadMailWorkspace(document.getElementById('mailSearch')?.value ?? ''));

document.getElementById('globalSearch')?.addEventListener('keydown', (event) => { if(event.key!=='Enter')return;event.preventDefault();openTab('mail');const q=event.currentTarget.value;const field=document.getElementById('mailSearch');if(field)field.value=q;void loadMailWorkspace(q); });

document.getElementById('composeClose')?.addEventListener('click', closeCompose);
document.getElementById('composeOverlay')?.addEventListener('click', (event) => { if(event.target.id==='composeOverlay')closeCompose(); });
document.getElementById('composeDraft')?.addEventListener('click', () => void submitCompose(false));
document.getElementById('composeSend')?.addEventListener('click', () => void submitCompose(true));

void loadStatus();
void loadHandoffs();
