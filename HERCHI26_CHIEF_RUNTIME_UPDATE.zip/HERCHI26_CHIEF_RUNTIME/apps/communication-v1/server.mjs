import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir, platform } from 'node:os';
import { execFileSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';

const APP_ID = 'COMMS';
const PORT = Number(process.env.HERCHI26_COMMUNICATION_PORT ?? 4261);
const here = path.dirname(fileURLToPath(import.meta.url));
const publicRoot = path.join(here, 'public');
const dataRoot = process.env.HERCHI26_COMMS_DATA_DIR ?? path.join(homedir(), 'Library', 'Application Support', 'HERCHI26', 'COMMS');
const handoffFile = path.join(dataRoot, 'mail-handoffs.json');
const attachmentRoot = path.join(homedir(), 'Documents', 'HERCHI26', 'COMMS', 'Attachments');

const corsHeaders = {
  'Access-Control-Allow-Origin': 'http://127.0.0.1:4260',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, {
    ...corsHeaders,
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(JSON.stringify(body));
}

async function readJson(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

async function serveStatic(requestUrl, response) {
  const rawPath = requestUrl === '/' ? '/index.html' : requestUrl;
  const pathname = decodeURIComponent(rawPath.split('?')[0]);
  const relative = pathname.replace(/^\/+/, '');
  const filePath = path.resolve(publicRoot, relative);
  if (!filePath.startsWith(`${path.resolve(publicRoot)}${path.sep}`) && filePath !== path.join(publicRoot, 'index.html')) return false;
  try {
    const content = await fs.readFile(filePath);
    response.writeHead(200, {
      'Content-Type': contentTypes[path.extname(filePath)] ?? 'application/octet-stream',
      'Cache-Control': 'no-store',
    });
    response.end(content);
    return true;
  } catch {
    return false;
  }
}

function appleMailErrorKind(message) {
  const text = String(message ?? '').toLowerCase();
  if (text.includes('not authorized') || text.includes('nicht autorisiert') || text.includes('-1743')) return 'PERMISSION_REQUIRED';
  if (text.includes('application isn’t running') || text.includes('application is not running')) return 'MAIL_NOT_RUNNING';
  if (text.includes('timed out')) return 'APPLE_MAIL_TIMEOUT';
  if (text.includes('sender_assign_failed') || text.includes('sender address') || text.includes('sender')) return 'SENDER_ACCOUNT_ERROR';
  if (text.includes('send_failed') || text.includes('smtp') || text.includes('cannot send') || text.includes('konnte nicht gesendet')) return 'MAIL_SEND_FAILED';
  return 'APPLE_MAIL_ERROR';
}

function runAppleMailJxa(source, timeout = 15000) {
  if (platform() !== 'darwin') {
    const error = new Error('APPLE_MAIL_UNAVAILABLE_ON_THIS_PLATFORM');
    error.code = 'UNSUPPORTED_PLATFORM';
    throw error;
  }
  try {
    const stdout = execFileSync('/usr/bin/osascript', ['-l', 'JavaScript', '-e', source], {
      encoding: 'utf8', timeout, maxBuffer: 8 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'],
    });
    return JSON.parse(stdout.trim() || '{}');
  } catch (error) {
    const stderr = error?.stderr?.toString?.() ?? '';
    const wrapped = new Error(stderr.trim() || error?.message || 'Apple Mail Zugriff fehlgeschlagen');
    wrapped.code = appleMailErrorKind(wrapped.message);
    throw wrapped;
  }
}

function commonJxaHelpers() {
  return String.raw`
    var Mail = Application('Mail');
    Mail.activate();
    function safe(fn, fallback) { try { return fn(); } catch (e) { return fallback; } }
    function lower(v) { return String(v || '').toLowerCase(); }
    function targetAccount() {
    var accounts = Mail.accounts();
    var exchangeFallback = null;
    for (var i = 0; i < accounts.length; i++) {
      var emails = safe(function(){ return accounts[i].emailAddresses(); }, []);
      for (var e = 0; e < emails.length; e++) {
        if (lower(emails[e]).indexOf('herchi26.de') >= 0) return accounts[i];
      }
      var name = lower(safe(function(){ return accounts[i].name(); }, ''));
      if (!exchangeFallback && (name.indexOf('exchange') >= 0 || name.indexOf('microsoft') >= 0 || name.indexOf('office') >= 0)) exchangeFallback = accounts[i];
    }
    if (exchangeFallback) return exchangeFallback;
    return accounts.length === 1 ? accounts[0] : null;
  }
  function accountPrimaryAddress(account) {
    if (!account) return '';
    var emails = safe(function(){ return account.emailAddresses(); }, []);
    for (var i = 0; i < emails.length; i++) {
      if (lower(emails[i]).indexOf('herchi26.de') >= 0) return String(emails[i]);
    }
    return emails.length ? String(emails[0]) : '';
  }
    function mailboxAliases(key) {
      var k = lower(key);
      if (k === 'inbox') return ['inbox','eingang','posteingang'];
      if (k === 'sent') return ['sent','sent messages','sent items','gesendet','gesendete elemente','gesendete objekte'];
      if (k === 'drafts') return ['drafts','entwürfe','entwuerfe'];
      if (k === 'trash') return ['trash','deleted messages','deleted items','papierkorb','gelöscht','geloescht','gelöschte elemente'];
      if (k === 'archive') return ['archive','archiv'];
      return [k];
    }
    function findMailbox(account, key) {
      if (!account) return null;
      var boxes = safe(function(){ return account.mailboxes(); }, []);
      var aliases = mailboxAliases(key);
      for (var i = 0; i < boxes.length; i++) {
        var n = lower(safe(function(){ return boxes[i].name(); }, ''));
        if (aliases.indexOf(n) >= 0) return boxes[i];
      }
      for (var j = 0; j < boxes.length; j++) {
        var n2 = lower(safe(function(){ return boxes[j].name(); }, ''));
        if (n2.indexOf(lower(key)) >= 0) return boxes[j];
      }
      return null;
    }
    function messageKey(msg) {
      var id = safe(function(){ return msg.id(); }, null);
      if (id !== null && id !== undefined) return String(id);
      return String(safe(function(){ return msg.messageId(); }, ''));
    }
    function findMessage(account, folderKey, wantedId) {
      var box = findMailbox(account, folderKey || 'INBOX');
      if (!box) return { box: null, msg: null };
      var all = safe(function(){ return box.messages(); }, []);
      for (var i = 0; i < all.length; i++) {
        var key = messageKey(all[i]);
        var mid = String(safe(function(){ return all[i].messageId(); }, ''));
        if (key === String(wantedId) || mid === String(wantedId)) return { box: box, msg: all[i] };
      }
      return { box: box, msg: null };
    }
    function attachmentRows(msg) {
      var list = safe(function(){ return msg.mailAttachments(); }, []);
      var out = [];
      for (var i = 0; i < list.length; i++) {
        out.push({
          index: i,
          name: safe(function(){ return list[i].name(); }, 'Anhang ' + (i + 1)),
          size: safe(function(){ return list[i].fileSize(); }, null),
          downloaded: Boolean(safe(function(){ return list[i].downloaded(); }, false))
        });
      }
      return out;
    }
    function messageRow(msg) {
      var received = safe(function(){ return msg.dateReceived(); }, null);
      var sender = safe(function(){ return msg.sender(); }, '');
      return {
        id: messageKey(msg),
        messageId: safe(function(){ return msg.messageId(); }, null),
        subject: safe(function(){ return msg.subject(); }, '(Kein Betreff)'),
        sender: sender,
        from: { name: sender, address: null },
        receivedDateTime: received && received.toISOString ? received.toISOString() : (received ? String(received) : null),
        isRead: Boolean(safe(function(){ return msg.readStatus(); }, false)),
        isFlagged: Boolean(safe(function(){ return msg.flaggedStatus(); }, false)),
        attachmentCount: safe(function(){ return msg.mailAttachments().length; }, 0)
      };
    }
  `;
}

function appleMailStatusScript() {
  return `${commonJxaHelpers()}
    var account = targetAccount();
    var accounts = Mail.accounts();
    var accountRows = accounts.map(function(a){ return { name: safe(function(){return a.name();},''), emails: safe(function(){return a.emailAddresses();},[]) }; });
    var result = { available:true, accounts:accountRows, exchange:{present:false,connected:false}, checkedAt:new Date().toISOString() };
    if (account) {
      var inbox = findMailbox(account, 'INBOX');
      var emails = safe(function(){ return account.emailAddresses(); }, []);
      result.exchange = {
        present:true, connected:true,
        accountName:safe(function(){return account.name();},'Exchange'),
        address:emails.length ? emails[0] : null,
        unread:inbox ? safe(function(){return inbox.unreadCount();},null) : null,
        total:inbox ? safe(function(){return inbox.messages().length;},null) : null,
        inboxFound:Boolean(inbox)
      };
    }
    JSON.stringify(result);`;
}

function foldersScript() {
  return `${commonJxaHelpers()}
    var account = targetAccount();
    var rows = [];
    if (account) {
      var boxes = safe(function(){ return account.mailboxes(); }, []);
      for (var i=0;i<boxes.length;i++) rows.push({
        name:safe(function(){return boxes[i].name();},''),
        unread:safe(function(){return boxes[i].unreadCount();},null),
        total:safe(function(){return boxes[i].messages().length;},null)
      });
    }
    JSON.stringify({ folders: rows });`;
}

function messagesScript(folder, limit, query = '') {
  const input = JSON.stringify({ folder, limit: Math.max(1, Math.min(100, Number(limit) || 25)), query: String(query || '').toLowerCase() });
  return `${commonJxaHelpers()}
    var input = ${input};
    var account = targetAccount();
    var rows = [];
    var box = account ? findMailbox(account, input.folder || 'INBOX') : null;
    if (box) {
      var all = safe(function(){ return box.messages(); }, []);
      for (var i=0;i<all.length && rows.length<input.limit;i++) {
        var row = messageRow(all[i]);
        if (input.query) {
          var hay = lower(row.subject + ' ' + row.sender + ' ' + safe(function(){return all[i].content();},''));
          if (hay.indexOf(input.query) < 0) continue;
        }
        rows.push(row);
      }
    }
    JSON.stringify({ messages:rows, folder:input.folder, error:box ? null : 'MAILBOX_NOT_FOUND' });`;
}

function detailScript(folder, id) {
  const input = JSON.stringify({ folder, id: String(id) });
  return `${commonJxaHelpers()}
    var input=${input}; var account=targetAccount(); var found=findMessage(account,input.folder,input.id);
    if (!found.msg) JSON.stringify({ message:null, error:'MESSAGE_NOT_FOUND' });
    else {
      var row=messageRow(found.msg);
      row.content=safe(function(){return found.msg.content();},'').slice(0,250000);
      row.to=safe(function(){return found.msg.toRecipients().map(function(r){return r.address();});},[]);
      row.cc=safe(function(){return found.msg.ccRecipients().map(function(r){return r.address();});},[]);
      row.attachments=attachmentRows(found.msg);
      JSON.stringify({message:row,error:null});
    }`;
}

function actionScript(input) {
  const payload = JSON.stringify(input);
  return `${commonJxaHelpers()}
    var input=${payload}; var account=targetAccount(); var found=findMessage(account,input.folder || 'INBOX',input.id);
    if (!found.msg) JSON.stringify({ok:false,error:'MESSAGE_NOT_FOUND'});
    else {
      var action=lower(input.action); var target=null;
      if (action==='read') found.msg.readStatus=true;
      else if (action==='unread') found.msg.readStatus=false;
      else if (action==='flag') found.msg.flaggedStatus=true;
      else if (action==='unflag') found.msg.flaggedStatus=false;
      else if (action==='delete') Mail.delete(found.msg);
      else if (action==='archive') { target=findMailbox(account,'ARCHIVE'); if(!target) throw new Error('ARCHIVE_NOT_FOUND'); Mail.move(found.msg,{to:target}); }
      else if (action==='move') { target=findMailbox(account,input.targetFolder); if(!target) throw new Error('TARGET_MAILBOX_NOT_FOUND'); Mail.move(found.msg,{to:target}); }
      else throw new Error('UNKNOWN_ACTION');
      JSON.stringify({ok:true,action:action});
    }`;
}

function composeScript(input) {
  const payload = JSON.stringify(input);
  return `${commonJxaHelpers()}
    var input=${payload};
    var account=targetAccount();
    if(!account) throw new Error('HERCHI26_ACCOUNT_NOT_FOUND');
    var senderAddress=accountPrimaryAddress(account);
    if(!senderAddress) throw new Error('HERCHI26_SENDER_ADDRESS_NOT_FOUND');
    var accountName=safe(function(){return account.name();},'Exchange');
    var msg=Mail.OutgoingMessage({subject:String(input.subject||''),content:String(input.body||'')+'\\n',visible:!input.send});
    Mail.outgoingMessages.push(msg);
    try { msg.sender=senderAddress; } catch(e) { throw new Error('SENDER_ASSIGN_FAILED ['+senderAddress+']: '+String(e)); }
    function addRecipients(list, ctor) { (list||[]).forEach(function(address){ if(address) msg[ctor].push(Mail[ctor==='toRecipients'?'ToRecipient':ctor==='ccRecipients'?'CcRecipient':'BccRecipient']({address:String(address)})); }); }
    addRecipients(input.to,'toRecipients'); addRecipients(input.cc,'ccRecipients'); addRecipients(input.bcc,'bccRecipients');
    if (input.send) {
      try { Mail.send(msg); } catch(e) { throw new Error('SEND_FAILED ['+senderAddress+']: '+String(e)); }
    }
    JSON.stringify({ok:true,sent:Boolean(input.send),draftOpened:!input.send,sender:senderAddress,accountName:accountName});`;
}

function replyForwardScript(input) {
  const payload = JSON.stringify(input);
  return `${commonJxaHelpers()}
    var input=${payload}; var account=targetAccount(); var found=findMessage(account,input.folder||'INBOX',input.id);
    if(!found.msg) JSON.stringify({ok:false,error:'MESSAGE_NOT_FOUND'});
    else {
      var out;
      if(input.mode==='forward') out=Mail.forward(found.msg,{openingWindow:!input.send});
      else out=Mail.reply(found.msg,{openingWindow:!input.send,replyToAll:input.mode==='replyAll'});
      var old=safe(function(){return out.content();},'');
      if(input.body) out.content=String(input.body)+'\\n\\n'+old;
      if(input.send) { try { Mail.send(out); } catch(e) { throw new Error('SEND_FAILED: '+String(e)); } }
      JSON.stringify({ok:true,mode:input.mode,sent:Boolean(input.send),draftOpened:!input.send});
    }`;
}

function saveAttachmentsScript(input) {
  const payload = JSON.stringify(input);
  return `${commonJxaHelpers()}
    var input=${payload}; var account=targetAccount(); var found=findMessage(account,input.folder||'INBOX',input.id);
    if(!found.msg) JSON.stringify({ok:false,error:'MESSAGE_NOT_FOUND',files:[]});
    else {
      var atts=safe(function(){return found.msg.mailAttachments();},[]); var files=[];
      for(var i=0;i<atts.length;i++) {
        var name=safe(function(){return atts[i].name();},'Anhang-'+(i+1));
        var dest=input.directory+'/'+name.replace(/[\\/:*?\"<>|]/g,'_');
        try { Mail.save(atts[i],{in:Path(dest)}); files.push(dest); } catch(e) { files.push(null); }
      }
      JSON.stringify({ok:true,files:files.filter(function(v){return Boolean(v);})});
    }`;
}

async function getLocalAppleMailStatus() {
  if (platform() !== 'darwin') return { source:'APPLE_MAIL_LOCAL', available:false, permissionRequired:false, exchange:{present:false,connected:false}, accounts:[], error:'UNSUPPORTED_PLATFORM', checkedAt:new Date().toISOString() };
  try {
    const data = runAppleMailJxa(appleMailStatusScript());
    return { source:'APPLE_MAIL_LOCAL', permissionRequired:false, error:null, ...data };
  } catch (error) {
    return { source:'APPLE_MAIL_LOCAL', available:true, permissionRequired:error.code==='PERMISSION_REQUIRED', exchange:{present:true,connected:false}, accounts:[], error:error.code ?? 'APPLE_MAIL_ERROR', errorMessage:error.message, checkedAt:new Date().toISOString() };
  }
}

function toMailStatus(local) {
  const connected=Boolean(local.exchange?.connected);
  return {
    appId:APP_ID, client:'Apple Mail', source:'APPLE_MAIL_LOCAL',
    exchange:{ present:Boolean(local.exchange?.present), connected, state:connected?'ONLINE':local.permissionRequired?'PERMISSION_REQUIRED':'WARNING', message:connected?'Exchange wird lokal über Apple Mail verwendet.':local.permissionRequired?'macOS Automation-Berechtigung für Mail erforderlich.':'Exchange konnte in Apple Mail noch nicht lokal gelesen werden.' },
    account:connected?{displayName:local.exchange.accountName??'Exchange',address:local.exchange.address??null}:null,
    unread:connected?local.exchange.unread??null:null, total:connected?local.exchange.total??null:null,
    lastSync:connected?local.checkedAt:null, appleMailPermissionRequired:Boolean(local.permissionRequired), graphConfigured:false, checkedAt:new Date().toISOString(),
  };
}

async function ensureDataRoot() { await fs.mkdir(dataRoot,{recursive:true}); }
async function readHandoffs() { try { return JSON.parse(await fs.readFile(handoffFile,'utf8')); } catch { return []; } }
async function writeHandoffs(rows) { await ensureDataRoot(); await fs.writeFile(handoffFile,JSON.stringify(rows,null,2)+'\n',{mode:0o600}); }

async function getDetail(folder,id) {
  const result=runAppleMailJxa(detailScript(folder,id),20000);
  if(result.error) { const e=new Error(result.error); e.code=result.error; throw e; }
  return result.message;
}

async function saveAttachments(folder,id,subdir) {
  const directory=path.join(attachmentRoot,subdir);
  await fs.mkdir(directory,{recursive:true});
  const result=runAppleMailJxa(saveAttachmentsScript({folder,id,directory}),30000);
  if(!result.ok) { const e=new Error(result.error||'ATTACHMENT_SAVE_FAILED'); e.code=result.error; throw e; }
  return result.files??[];
}

const server=http.createServer(async(request,response)=>{
  if(request.method==='OPTIONS'){response.writeHead(204,corsHeaders);response.end();return;}
  const requestUrl=new URL(request.url??'/',`http://127.0.0.1:${PORT}`);

  if(request.method==='GET'&&requestUrl.pathname==='/health'){
    const local=await getLocalAppleMailStatus();
    sendJson(response,200,{appId:APP_ID,name:'HERCHI26 COMMS V1',version:'0.5.2',status:'ONLINE',ui:'C_DARK',mailSource:'APPLE_MAIL_LOCAL',exchangeConnected:Boolean(local.exchange?.connected),checkedAt:new Date().toISOString()});return;
  }
  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/status'){sendJson(response,200,toMailStatus(await getLocalAppleMailStatus()));return;}
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/local/connect'){
    const local=await getLocalAppleMailStatus(); sendJson(response,local.exchange?.connected?200:409,{status:toMailStatus(local),permissionRequired:Boolean(local.permissionRequired),message:local.exchange?.connected?'Apple Mail ist lokal verbunden.':local.permissionRequired?'Bitte die macOS-Berechtigung zum Steuern von Mail erlauben und erneut prüfen.':'Exchange-Konto oder Inbox konnte in Apple Mail noch nicht erkannt werden.'});return;
  }
  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/folders'){
    try{const result=runAppleMailJxa(foldersScript(),15000);sendJson(response,200,result);}catch(error){sendJson(response,409,{error:error.code??'FOLDER_READ_FAILED',message:error.message});}return;
  }
  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/messages'){
    try{const result=runAppleMailJxa(messagesScript(requestUrl.searchParams.get('folder')??'INBOX',requestUrl.searchParams.get('limit')??25,requestUrl.searchParams.get('q')??''),30000);if(result.error)throw Object.assign(new Error(result.error),{code:result.error});sendJson(response,200,{source:'APPLE_MAIL_LOCAL',...result});}catch(error){sendJson(response,409,{error:error.code??'MAIL_READ_FAILED',message:error.message});}return;
  }
  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/message'){
    try{const message=await getDetail(requestUrl.searchParams.get('folder')??'INBOX',requestUrl.searchParams.get('id')??'');sendJson(response,200,{message});}catch(error){sendJson(response,404,{error:error.code??'MESSAGE_READ_FAILED',message:error.message});}return;
  }
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/action'){
    try{const body=await readJson(request);const result=runAppleMailJxa(actionScript(body),20000);if(!result.ok)throw Object.assign(new Error(result.error),{code:result.error});sendJson(response,200,result);}catch(error){sendJson(response,409,{error:error.code??'MAIL_ACTION_FAILED',message:error.message});}return;
  }
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/compose'){
    try{const body=await readJson(request);if(!Array.isArray(body.to)||body.to.length===0){sendJson(response,400,{error:'RECIPIENT_REQUIRED',message:'Mindestens ein Empfänger ist erforderlich.'});return;}const result=runAppleMailJxa(composeScript(body),20000);sendJson(response,200,result);}catch(error){sendJson(response,409,{error:error.code??'COMPOSE_FAILED',message:error.message});}return;
  }
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/respond'){
    try{const body=await readJson(request);if(!['reply','replyAll','forward'].includes(body.mode)){sendJson(response,400,{error:'INVALID_MODE'});return;}const result=runAppleMailJxa(replyForwardScript(body),20000);if(!result.ok)throw Object.assign(new Error(result.error),{code:result.error});sendJson(response,200,result);}catch(error){sendJson(response,409,{error:error.code??'RESPOND_FAILED',message:error.message});}return;
  }
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/attachments/save'){
    try{const body=await readJson(request);const files=await saveAttachments(body.folder??'INBOX',body.id,String(body.id||'mail'));sendJson(response,200,{files});}catch(error){sendJson(response,409,{error:error.code??'ATTACHMENT_SAVE_FAILED',message:error.message});}return;
  }
  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/handoffs'){sendJson(response,200,{handoffs:await readHandoffs()});return;}
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/handoff'){
    try{
      const body=await readJson(request);const target=String(body.target??'').toUpperCase();if(!['SUPPORT','FINANCE'].includes(target)){sendJson(response,400,{error:'INVALID_HANDOFF_TARGET'});return;}
      const message=await getDetail(body.folder??'INBOX',body.id);const handoffId=`H26-MAIL-${new Date().toISOString().replace(/\D/g,'').slice(0,14)}-${randomUUID().slice(0,8)}`;
      let attachments=[];if(target==='FINANCE'&&message.attachmentCount>0) attachments=await saveAttachments(body.folder??'INBOX',body.id,`${target}/${handoffId}`);
      const rows=await readHandoffs();const record={id:handoffId,target,status:'PREPARED',createdAt:new Date().toISOString(),source:'APPLE_MAIL_LOCAL',folder:body.folder??'INBOX',message:{id:message.id,messageId:message.messageId,subject:message.subject,sender:message.sender,receivedDateTime:message.receivedDateTime,attachmentCount:message.attachmentCount},attachments,note:String(body.note??'')};rows.unshift(record);await writeHandoffs(rows.slice(0,1000));sendJson(response,200,{handoff:record});
    }catch(error){sendJson(response,409,{error:error.code??'HANDOFF_FAILED',message:error.message});}return;
  }

  if(request.method==='GET'&&requestUrl.pathname==='/v1/mail/config'){sendJson(response,200,{configured:false,primary:'APPLE_MAIL_LOCAL',scopes:[]});return;}
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/connect'){const local=await getLocalAppleMailStatus();sendJson(response,local.exchange?.connected?200:409,{primary:'APPLE_MAIL_LOCAL',status:toMailStatus(local),permissionRequired:Boolean(local.permissionRequired)});return;}
  if(request.method==='POST'&&requestUrl.pathname==='/v1/mail/disconnect'){sendJson(response,200,{disconnected:false,message:'Apple Mail bleibt unverändert verbunden.'});return;}

  if(request.method==='POST'&&requestUrl.pathname==='/v1/orders'){
    try{const order=await readJson(request);if(!order?.orderId||order.appId!==APP_ID||!order?.title){sendJson(response,400,{error:'INVALID_ORDER',message:'orderId, appId=COMMS and title are required'});return;}sendJson(response,200,{orderId:order.orderId,appId:APP_ID,status:'COMPLETED',finishedAt:new Date().toISOString(),summary:`COMMS V1 hat den Auftrag "${order.title}" verarbeitet.`,costCents:0,messages:['Auftrag von Chief empfangen','Fach-App unabhängig ausgeführt','Ergebnis an Chief zurückgegeben'],decisions:['Keine manuelle Entscheidung erforderlich'],result:{acceptedPayload:order.payload??{},proof:'chief-app-result-chief-v1'}});}catch(error){sendJson(response,500,{error:'EXECUTION_FAILED',message:error instanceof Error?error.message:'Unknown error'});}return;
  }

  if(request.method==='GET'&&(await serveStatic(request.url??'/',response)))return;
  sendJson(response,404,{error:'NOT_FOUND'});
});

server.listen(PORT,'127.0.0.1',()=>console.log(`HERCHI26 COMMS V1 listening on http://127.0.0.1:${PORT}`));
