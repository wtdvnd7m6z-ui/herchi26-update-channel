import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';

function arg(name) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : null;
}

const runtimeRoot = arg('runtime');
const archive = arg('archive');
const expectedVersion = arg('version');
const parentPid = Number(arg('parent-pid') ?? 0);
const browser = arg('browser') !== '0';

if (!runtimeRoot || !archive || !expectedVersion) {
  console.error('Usage: apply-update-v1.mjs --runtime <dir> --archive <zip> --version <version> [--parent-pid <pid>]');
  process.exit(2);
}

const parentDir = path.dirname(runtimeRoot);
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const staging = path.join(parentDir, `.HERCHI26_CHIEF_update_${stamp}`);
const backup = `${runtimeRoot}.backup-${stamp}`;
const failed = `${runtimeRoot}.failed-${stamp}`;
const logFile = path.join(process.env.HOME ?? parentDir, 'Library', 'Logs', 'HERCHI26-Chief-Updater.log');

async function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  await fs.mkdir(path.dirname(logFile), { recursive: true }).catch(() => {});
  await fs.appendFile(logFile, line).catch(() => {});
  console.log(message);
}

async function exists(file) {
  try { await fs.access(file); return true; } catch { return false; }
}

async function waitForParentExit() {
  if (!parentPid) return;
  for (let i = 0; i < 80; i += 1) {
    try {
      process.kill(parentPid, 0);
      await sleep(125);
    } catch {
      return;
    }
  }
  await log(`Runtime PID ${parentPid} did not exit in time; continuing with port cleanup.`);
}

function killLocalPorts() {
  if (process.platform !== 'darwin') return;
  for (const port of [4259, 4260, 4261]) {
    try {
      const output = execFileSync('/usr/sbin/lsof', ['-ti', `tcp:${port}`], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
      for (const pid of output.trim().split(/\s+/).filter(Boolean)) {
        try { process.kill(Number(pid), 'SIGTERM'); } catch {}
      }
    } catch {}
  }
}

async function readVersion(root) {
  for (const candidate of [
    path.join(root, 'apps', 'chief-v1', 'dist', 'version.json'),
    path.join(root, 'apps', 'chief-v1', 'public', 'version.json'),
  ]) {
    try { return JSON.parse(await fs.readFile(candidate, 'utf8')); } catch {}
  }
  throw new Error('PAYLOAD_VERSION_NOT_FOUND');
}

async function waitOnline(url, attempts = 80) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(700) });
      if (response.ok) return true;
    } catch {}
    await sleep(250);
  }
  return false;
}

function startInstalledRuntime(openBrowser = false) {
  const script = path.join(runtimeRoot, 'scripts', 'launch-herchi26-v1.mjs');
  const child = spawn(process.execPath, [script], {
    cwd: runtimeRoot,
    detached: true,
    stdio: 'ignore',
    env: { ...process.env, HERCHI26_NO_BROWSER: openBrowser ? '0' : '1' },
  });
  child.unref();
}

async function refreshMacApp() {
  if (process.platform !== 'darwin') return;
  const builder = path.join(runtimeRoot, 'scripts', 'build-herchi26-chief-mac-app.mjs');
  if (!(await exists(builder))) return;
  try {
    execFileSync(process.execPath, [builder, '--install'], { cwd: runtimeRoot, stdio: 'ignore' });
    await log('HERCHI26 Chief.app refreshed.');
  } catch (error) {
    await log(`App bundle refresh warning: ${error instanceof Error ? error.message : String(error)}`);
  }
}

async function extractPayload() {
  await fs.rm(staging, { recursive: true, force: true });
  await fs.mkdir(staging, { recursive: true });
  execFileSync('unzip', ['-q', archive, '-d', staging], { stdio: 'ignore' });
  const preferred = path.join(staging, 'HERCHI26_CHIEF_RUNTIME');
  const payload = await exists(preferred) ? preferred : staging;
  const version = await readVersion(payload);
  if (String(version.version) !== String(expectedVersion)) {
    throw new Error(`PAYLOAD_VERSION_MISMATCH expected=${expectedVersion} actual=${version.version}`);
  }
  for (const required of [
    path.join(payload, 'scripts', 'start-chief-v1.mjs'),
    path.join(payload, 'scripts', 'launch-herchi26-v1.mjs'),
    path.join(payload, 'apps', 'chief-v1', 'dist', 'index.html'),
    path.join(payload, 'apps', 'communication-v1', 'server.mjs'),
  ]) {
    if (!(await exists(required))) throw new Error(`PAYLOAD_FILE_MISSING ${required}`);
  }
  return payload;
}

async function rollback(reason) {
  await log(`ROLLBACK: ${reason}`);
  killLocalPorts();
  await sleep(500);
  if (await exists(runtimeRoot)) await fs.rename(runtimeRoot, failed).catch(() => {});
  if (await exists(backup)) await fs.rename(backup, runtimeRoot);
  startInstalledRuntime(false);
  await waitOnline('http://127.0.0.1:4259/health', 80);
  if (process.platform === 'darwin' && browser) {
    spawn('/usr/bin/open', ['http://127.0.0.1:4260'], { detached: true, stdio: 'ignore' }).unref();
  }
}

let swapped = false;
try {
  await log(`Applying HERCHI26 update ${expectedVersion} from ${archive}`);
  await waitForParentExit();
  killLocalPorts();
  await sleep(600);
  const payload = await extractPayload();

  await fs.rm(backup, { recursive: true, force: true });
  await fs.rename(runtimeRoot, backup);
  swapped = true;
  if (payload === staging) {
    await fs.rename(staging, runtimeRoot);
  } else {
    await fs.rename(payload, runtimeRoot);
    await fs.rm(staging, { recursive: true, force: true });
  }

  await refreshMacApp();
  startInstalledRuntime(false);
  const runtimeReady = await waitOnline('http://127.0.0.1:4259/health', 100);
  const chiefReady = runtimeReady && await waitOnline('http://127.0.0.1:4260', 100);
  const commsReady = runtimeReady && await waitOnline('http://127.0.0.1:4261/health', 100);
  if (!runtimeReady || !chiefReady || !commsReady) {
    throw new Error(`POST_UPDATE_HEALTH_FAILED runtime=${runtimeReady} chief=${chiefReady} comms=${commsReady}`);
  }

  const installed = await readVersion(runtimeRoot);
  if (String(installed.version) !== String(expectedVersion)) throw new Error('POST_UPDATE_VERSION_MISMATCH');
  await log(`PASS update installed: ${installed.version} ${installed.buildId ?? ''}`);
  if (process.platform === 'darwin' && browser) {
    spawn('/usr/bin/open', ['http://127.0.0.1:4260'], { detached: true, stdio: 'ignore' }).unref();
  }
  process.exit(0);
} catch (error) {
  const message = error instanceof Error ? error.stack ?? error.message : String(error);
  await log(`UPDATE FAILED: ${message}`);
  if (swapped) await rollback(message);
  else {
    await fs.rm(staging, { recursive: true, force: true }).catch(() => {});
    if (await exists(runtimeRoot)) startInstalledRuntime(false);
  }
  process.exit(1);
}
