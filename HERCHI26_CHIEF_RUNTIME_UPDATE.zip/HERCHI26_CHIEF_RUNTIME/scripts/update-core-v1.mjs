import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';

export const UPDATE_DATA_ROOT = path.join(homedir(), 'Library', 'Application Support', 'HERCHI26');
export const UPDATE_CONFIG_FILE = path.join(UPDATE_DATA_ROOT, 'update-channel.json');
export const UPDATE_CACHE_DIR = path.join(UPDATE_DATA_ROOT, 'update-cache');

function normalizeVersion(value) {
  return String(value ?? '').trim().replace(/^v/i, '');
}

export function compareVersions(a, b) {
  const pa = normalizeVersion(a).split('.').map((part) => Number.parseInt(part, 10) || 0);
  const pb = normalizeVersion(b).split('.').map((part) => Number.parseInt(part, 10) || 0);
  const length = Math.max(pa.length, pb.length, 3);
  for (let i = 0; i < length; i += 1) {
    const av = pa[i] ?? 0;
    const bv = pb[i] ?? 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

async function readJsonFile(file) {
  return JSON.parse(await fs.readFile(file, 'utf8'));
}

async function readJsonResource(resource) {
  if (!resource) throw new Error('UPDATE_CHANNEL_NOT_CONFIGURED');
  if (/^https?:\/\//i.test(resource)) {
    const response = await fetch(resource, { cache: 'no-store', signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new Error(`UPDATE_MANIFEST_HTTP_${response.status}`);
    return response.json();
  }
  if (resource.startsWith('file://')) return readJsonFile(new URL(resource));
  return readJsonFile(resource);
}

export async function getUpdateChannelConfig() {
  if (process.env.HERCHI26_UPDATE_MANIFEST_URL) {
    return { manifestUrl: process.env.HERCHI26_UPDATE_MANIFEST_URL, source: 'ENV' };
  }
  try {
    const config = await readJsonFile(UPDATE_CONFIG_FILE);
    return { manifestUrl: config.manifestUrl ?? null, source: 'FILE' };
  } catch {
    return { manifestUrl: null, source: 'NONE' };
  }
}

export async function setUpdateChannelConfig(manifestUrl) {
  await fs.mkdir(UPDATE_DATA_ROOT, { recursive: true });
  await fs.writeFile(UPDATE_CONFIG_FILE, `${JSON.stringify({ manifestUrl }, null, 2)}\n`, { mode: 0o600 });
  return { manifestUrl, source: 'FILE' };
}

export async function readCurrentVersion(runtimeRoot) {
  const candidates = [
    path.join(runtimeRoot, 'apps', 'chief-v1', 'dist', 'version.json'),
    path.join(runtimeRoot, 'apps', 'chief-v1', 'public', 'version.json'),
  ];
  for (const candidate of candidates) {
    try {
      const version = await readJsonFile(candidate);
      return { ...version, sourceFile: candidate };
    } catch {
      // next candidate
    }
  }
  throw new Error('CURRENT_VERSION_NOT_FOUND');
}

function resolvePackageUrl(manifestUrl, packageUrl) {
  if (!packageUrl) throw new Error('UPDATE_PACKAGE_URL_MISSING');
  if (/^https?:\/\//i.test(packageUrl) || packageUrl.startsWith('file://')) return packageUrl;
  if (/^https?:\/\//i.test(manifestUrl) || manifestUrl.startsWith('file://')) return new URL(packageUrl, manifestUrl).toString();
  return path.resolve(path.dirname(manifestUrl), packageUrl);
}

export async function checkForUpdate(runtimeRoot) {
  const current = await readCurrentVersion(runtimeRoot);
  const channel = await getUpdateChannelConfig();
  if (!channel.manifestUrl) {
    return {
      current,
      available: null,
      updateAvailable: false,
      channelConfigured: false,
      state: 'CHANNEL_REQUIRED',
      manifestUrl: null,
    };
  }

  try {
    const available = await readJsonResource(channel.manifestUrl);
    if (!available.version || !available.versionDate || !available.buildId || !available.sha256 || !available.packageUrl) {
      throw new Error('UPDATE_MANIFEST_INVALID');
    }
    const comparison = compareVersions(available.version, current.version);
    return {
      current,
      available,
      updateAvailable: comparison > 0,
      channelConfigured: true,
      state: comparison > 0 ? 'UPDATE_AVAILABLE' : comparison === 0 ? 'UP_TO_DATE' : 'LOCAL_NEWER',
      manifestUrl: channel.manifestUrl,
      packageUrl: resolvePackageUrl(channel.manifestUrl, available.packageUrl),
    };
  } catch (error) {
    return {
      current,
      available: null,
      updateAvailable: false,
      channelConfigured: true,
      state: 'CHANNEL_ERROR',
      manifestUrl: channel.manifestUrl,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function hashFile(file) {
  const hash = createHash('sha256');
  const content = await fs.readFile(file);
  hash.update(content);
  return hash.digest('hex');
}

async function downloadResource(resource, destination) {
  await fs.mkdir(path.dirname(destination), { recursive: true });
  if (/^https?:\/\//i.test(resource)) {
    const response = await fetch(resource, { signal: AbortSignal.timeout(30000) });
    if (!response.ok) throw new Error(`UPDATE_PACKAGE_HTTP_${response.status}`);
    await fs.writeFile(destination, Buffer.from(await response.arrayBuffer()));
    return;
  }
  if (resource.startsWith('file://')) {
    await fs.copyFile(new URL(resource), destination);
    return;
  }
  await fs.copyFile(resource, destination);
}

export async function prepareUpdate(runtimeRoot) {
  const status = await checkForUpdate(runtimeRoot);
  if (!status.channelConfigured) throw new Error('UPDATE_CHANNEL_NOT_CONFIGURED');
  if (!status.updateAvailable || !status.available || !status.packageUrl) throw new Error('NO_UPDATE_AVAILABLE');

  const filename = `HERCHI26-Chief-${status.available.version}.zip`;
  const destination = path.join(UPDATE_CACHE_DIR, filename);
  await downloadResource(status.packageUrl, destination);
  const actualSha = await hashFile(destination);
  const expectedSha = String(status.available.sha256).toLowerCase();
  if (actualSha.toLowerCase() !== expectedSha) {
    await fs.rm(destination, { force: true }).catch(() => {});
    throw new Error(`UPDATE_SHA256_MISMATCH expected=${expectedSha} actual=${actualSha}`);
  }

  return {
    archive: destination,
    current: status.current,
    available: status.available,
    sha256: actualSha,
    manifestUrl: status.manifestUrl,
  };
}
